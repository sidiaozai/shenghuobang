package com.avoscloud.beijing.push.demo.keepalive;

public interface MessageListener {

  public void onMessage(String msg);

}
