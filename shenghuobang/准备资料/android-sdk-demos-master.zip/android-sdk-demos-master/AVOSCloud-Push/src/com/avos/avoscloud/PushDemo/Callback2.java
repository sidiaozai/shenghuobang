package com.avos.avoscloud.PushDemo;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created with IntelliJ IDEA.
 * User: tangxiaomin
 * Date: 4/22/13
 * Time: 4:56 PM
 */
public class Callback2 extends Activity {
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.callback2);
    }
}