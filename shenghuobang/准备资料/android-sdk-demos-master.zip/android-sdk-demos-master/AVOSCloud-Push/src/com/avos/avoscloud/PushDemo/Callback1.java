package com.avos.avoscloud.PushDemo;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created with IntelliJ IDEA.
 * User: tangxiaomin
 * Date: 4/22/13
 * Time: 4:53 PM
 */
public class Callback1 extends Activity {
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.callback1);
    }
}